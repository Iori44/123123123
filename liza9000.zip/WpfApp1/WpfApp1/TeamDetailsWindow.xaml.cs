﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp1;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для TeamDetailsWindow.xaml
    /// </summary>
    public partial class TeamDetailsWindow : Window
    {
        public TeamDetailsWindow(Team currentTeam)
        {
            InitializeComponent();

            dGridRoster.ItemsSource = BasketballSystemEntities1.GetContext().PlayerInTeam.Where(p => p.TeamId == currentTeam.TeamId).ToList();
            DataContext = currentTeam;

            dataOfTeam.Content = currentTeam.TeamName + " | " + currentTeam.Division.Name + " of " + currentTeam.Division.Conference.Name;
        

          if (tabItem == 0)
    tabControl.SelectedIndex = 0;
else if (tabItem == 1)
    tabControl.SelectedIndex = 1;
else
    tabControl.SelectedIndex = 2;
        dGridRoster.ItemsSource = BasketballSystemEntities.GetContext().PlayerInTeam.Where(p => p.TeamId == currentTeam.TeamId).ToList();
        var matchups = BasketballSystemEntities.GetContext().Matchup.Where(p => p.TeamAway == currentTeam.TeamId || p.TeamHome == currentTeam.TeamId).ToList();
foreach (var matchup in matchups )
{
    foreach (var team in BasketballSystemEntities.GetContext().Team)
    {
        if ((currentTeam.TeamId == matchup.TeamAway) && (team.TeamId != currentTeam.TeamId))
            matchup.Opponent = team;
        else if ((currentTeam.TeamId == matchup.TeamHome) && (team.TeamId != currentTeam.TeamId))
            matchup.Opponent = team;
    }
    }
}
dGridMatchup.ItemsSource = matchups;
}
    private void BackWindowClick(object sender, RoutedEventArgs e)
        {

        }
    }
}
