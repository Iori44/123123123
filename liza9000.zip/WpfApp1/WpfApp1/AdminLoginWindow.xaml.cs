﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для AdminLoginWindow.xaml
    /// </summary>
    public partial class AdminLoginWindow : Window
    {
        public AdminLoginWindow()
        {
            InitializeComponent();
        }

        private void AdminLoginClick(object sender, RoutedEventArgs e)
        {
            foreach (var admin in BasketballSystemEntities1.GetContext().Admin) 
            { 
                if (inputJobnumber.Text == admin.Jobnumber)
                {
                    if (inputPassword.Text == admin.Passwords)
                    {
                        if (rememberUser.IsChecked == true)
                        {
                            new AdminMenuWindow(admin, true).Show();
                            Close();
                            return;
                        }
                        else
                        {
                            new AdminMenuWindow(admin).Show();
                            Close();
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Неверный пароль!", "Неверный пароль", MessageBoxButton.OK, MessageBoxImage.Information);
                        inputPassword.Text = "";
                        return;
                    }
                }
            }
            MessageBox.Show("Пользователя с таким логином не существует", "Неверный логин", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void BackWindowClick(object sender, RoutedEventArgs e)
        {
            new MainWindow().Show();
            Close();
        }
    }
}