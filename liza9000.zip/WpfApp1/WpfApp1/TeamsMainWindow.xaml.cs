﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для TeamsMainWindow.xaml
    /// </summary>
    public partial class TeamsMainWindow : Window
    {
        public TeamsMainWindow()
        {
            InitializeComponent();
            southeastTeams.ItemsSource = BasketballSystemEntities1.GetContext().Team.Where(p => p.DivisionId == 1).ToList();
            centralTeams.ItemsSource = BasketballSystemEntities1.GetContext().Team.Where(p => p.DivisionId == 2).ToList();
            atlanticTeams.ItemsSource = BasketballSystemEntities1.GetContext().Team.Where(p => p.DivisionId == 3).ToList();
            southwestTeams.ItemsSource = BasketballSystemEntities1.GetContext().Team.Where(p => p.DivisionId == 4).ToList();
            northwestTeams.ItemsSource = BasketballSystemEntities1.GetContext().Team.Where(p => p.DivisionId == 5).ToList();
            pacificTeams.ItemsSource = BasketballSystemEntities1.GetContext().Team.Where(p => p.DivisionId == 6).ToList();
        }

        private void BackWindowClick(object sender, RoutedEventArgs e)
        {
            new VisitorMenuWindow().Show();
            Close();
        }

        private void OpenTeamDetails(object sender, RoutedEventArgs e)
        {
            new TeamDetailsWindow((sender as Button).DataContext as Team).Show();
        }
    }
}
